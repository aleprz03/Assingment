import java.util.ArrayList;
import java.util.Arrays;

public class TablasF {

    private ArrayList<Categoria> tablaHO3;
    private ArrayList<Categoria> tablaHO4;
    private double[] data;

    public TablasF(String[] nombres, int[] frecuencias, double[] dataHO4) {
        this.data = dataHO4;
        construirHO3(nombres, frecuencias);
        construirHO4();
    }


    //        HO3
    private void construirHO3(String[] nombres, int[] frecuencias) {
        tablaHO3 = new ArrayList<>();

        int total = 0;
        for (int f : frecuencias) total += f;

        for (int i = 0; i < nombres.length; i++) {
            tablaHO3.add(new Categoria(nombres[i], frecuencias[i], total));
        }
    }

    public void imprimirHO3() {
        System.out.println("\n--- TABLA HO3 ---");
        System.out.println("MT        f    fr    %");

        int total = 0;
        for (Categoria c : tablaHO3) {
            System.out.printf("%-10s %-4d %-4.2f %.0f%%\n",
                    c.getNombre(), c.getFa(), c.getFr(), c.getPorcentaje());
            total += c.getFa();
        }

        System.out.println("------------------------");
        System.out.printf("%-10s %-4d %-4.2f %.0f%%\n",
                "TOTAL", total, 1.0, 100.0);
    }

    // =========================
    //        HO4
    // =========================
    private void construirHO4() {

        tablaHO4 = new ArrayList<>();
        Arrays.sort(data);

        double min = data[0];
        double max = data[data.length - 1];
        double rango = max - min;

        int k = (int) Math.ceil(1 + 3.322 * Math.log10(data.length));
        double amplitud = Math.ceil(rango / k);

        double li = min;

        // Crear clases
        for (int i = 0; i < k; i++) {
            double ls = li + amplitud;
            tablaHO4.add(new Categoria(li, ls));
            li = ls;
        }

        // Contar frecuencias
        for (double v : data) {
            for (Categoria c : tablaHO4) {
                if ((v >= c.getLi() && v < c.getLs()) || v == max) {
                    c.incrementarFA();
                    break;
                }
            }
        }

        // Frecuencias acumuladas
        int faAc = 0;
        double frAc = 0;

        for (Categoria c : tablaHO4) {
            double fr = c.getFa() / (double) data.length;
            c.setFr(fr);

            faAc += c.getFa();
            frAc += fr;

            c.setFaAc(faAc);
            c.setFrAc(frAc);
        }
    }

    public void imprimirHO4() {
        System.out.println("\n--- TABLA HO4 ---");
        System.out.println("Clase          f    fr    %   FA    FR    PM");

        for (Categoria c : tablaHO4) {
            System.out.printf("%5.1f - %-5.1f %-4d %-4.2f %-3.0f%% %-5d %-5.2f %-5.2f\n",
                    c.getLi(), c.getLs(), c.getFa(), c.getFr(), c.getPorcentaje(),
                    c.getFaAc(), c.getFrAc(), c.getPuntoMedio());
        }
    }

    // =========================
    //        HO5
    // =========================
    public void imprimirHO5() {
        System.out.println("\n--- HO5: MEDIDAS AGRUPADAS ---");

        System.out.printf("Media: %.2f\n", calcularMedia());
        System.out.printf("Moda: %.2f\n", calcularModa());
        System.out.printf("Mediana: %.2f\n", calcularMediana());
    }

    private double calcularMedia() {
        double suma = 0;
        for (Categoria c : tablaHO4) {
            suma += c.getPuntoMedio() * c.getFa();
        }
        return suma / data.length;
    }

    private double calcularModa() {
        Categoria mayor = tablaHO4.get(0);

        for (Categoria c : tablaHO4) {
            if (c.getFa() > mayor.getFa())
                mayor = c;
        }

        int i = tablaHO4.indexOf(mayor);

        double Li = mayor.getLi();
        double fm = mayor.getFa();
        double f1 = (i == 0 ? 0 : tablaHO4.get(i - 1).getFa());
        double f2 = (i == tablaHO4.size() - 1 ? 0 : tablaHO4.get(i + 1).getFa());
        double h = mayor.getLs() - mayor.getLi();

        return Li + ((fm - f1) / ((2 * fm) - f1 - f2)) * h;
    }

    private double calcularMediana() {
        int N = data.length;
        int mitad = N / 2;

        Categoria clase = null;
        for (Categoria c : tablaHO4) {
            if (c.getFaAc() >= mitad) {
                clase = c;
                break;
            }
        }

        int i = tablaHO4.indexOf(clase);

        double Li = clase.getLi();
        double h = clase.getLs() - clase.getLi();
        int FaPrev = (i == 0 ? 0 : tablaHO4.get(i - 1).getFaAc());
        int f = clase.getFa();

        return Li + ((double)(mitad - FaPrev) / f) * h;
    }
}
