public class Categoria {

    // Para HO3
    private String nombre;
    private int fa;
    private double fr;

    // Para HO4–HO5
    private double linf;
    private double lsup;
    private int faAc;
    private double frAc;


    // Constructor para HO3
    public Categoria(String nombre, int fa, int total) {
        this.nombre = nombre;
        this.fa = fa;
        this.fr = (double) fa / total;
    }

    // Constructor para HO4
    public Categoria(double li, double ls) {
        this.linf = li;
        this.lsup = ls;
        this.fa = 0;   // inicia sin datos
    }



    public String getNombre() { return nombre; }
    public int getFa() { return fa; }
    public double getFr() { return fr; }
    public double getLi() { return linf; }
    public double getLs() { return lsup; }
    public int getFaAc() { return faAc; }
    public double getFrAc() { return frAc; }



    public void setFr(double fr) { this.fr = fr; }
    public void setFaAc(int faAc) { this.faAc = faAc; }
    public void setFrAc(double frAc) { this.frAc = frAc; }



    public void incrementarFA() {
        fa++;
    }

    public double getPorcentaje() {
        return fr * 100;
    }

    public double getPuntoMedio() {
        return (linf + lsup) / 2.0;
    }
}
